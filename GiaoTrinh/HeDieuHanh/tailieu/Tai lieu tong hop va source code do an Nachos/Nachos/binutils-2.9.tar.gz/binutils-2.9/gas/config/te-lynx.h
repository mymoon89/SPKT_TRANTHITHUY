#define TE_LYNX

#include "obj-format.h"

#ifndef LOCAL_LABELS_FB
#define LOCAL_LABELS_FB 1
#endif
