#include "util.h"
#include "copyright.h"
int
main()
{  
  char a[2];
  print("\nThis is help.\n");

  Read(a,1,0);
  Halt();
}
