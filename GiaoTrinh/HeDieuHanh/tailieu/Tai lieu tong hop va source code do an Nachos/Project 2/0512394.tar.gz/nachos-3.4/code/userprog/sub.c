#include "syscall.h"
int main()
{
	int result;
	result = Sub(43,23);
	Halt();
	return 0;
}
