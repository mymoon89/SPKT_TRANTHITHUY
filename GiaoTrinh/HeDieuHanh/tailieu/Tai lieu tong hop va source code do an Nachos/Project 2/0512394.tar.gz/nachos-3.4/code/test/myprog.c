
#include "syscall.h"
#include "util.h"

int main()
{
	Write("\n--------Chuong trinh myprog. ",30,ConsoleOutput);
	Exit(0);
}
