#include "syscall.h"
#include "global.h"



int main()
{
	int i,len,id,Eindex;
	char buff[10];
	memset(buff,0,10);
	len = 0;
	id = 0;
	Eindex = 20;
	//Doc file
	/*	id = Open("Eindex.txt",ROFILE);
		len = Read(buff,10,id);
		Close(id);
		buff[len] = '\0';*/
	//Write("\nSo khi ben DONG la : ",20,ConsoleOutput);
	//Write(buff,10,ConsoleOutput);
	//Eindex = __atoi(buff);//chuoi thanh so
	//__itoa(Eindex,buff);
	//Write(buff,10,ConsoleOutput);

	for(i = 1; i <= Eindex ; ++i)
		Monkey(i,EAST);
	Exit(0);
	return 0;
}
