 
#include "syscall.h"

int main()
{
	char buff[1000];
	int kq;

	Write("\nBan nhap 1 chuoi ky tu :",50,ConsoleOutput);
	kq = Read(buff,1000,ConsoleInput);
	if(kq > 0)
	{	
		Write("\nChuoi ban vua nhap la :",30,ConsoleOutput);
		Write(buff,1000,ConsoleOutput);
	}
	else
	{
		Write("\nLoi : Co the ban chua nhap ky tu nao ",50,ConsoleOutput);	
	}
	Exit(0);
//	return 0;
}
