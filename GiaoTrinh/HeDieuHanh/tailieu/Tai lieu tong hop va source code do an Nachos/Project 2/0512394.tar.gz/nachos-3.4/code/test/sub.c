#include "syscall.h"

int main()
{
	int result = Sub(43,23);
	Exit(0);
//	return 0;
}
