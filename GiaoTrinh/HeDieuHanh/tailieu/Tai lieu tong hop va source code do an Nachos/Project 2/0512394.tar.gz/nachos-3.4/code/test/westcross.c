#include "syscall.h"
#include "global.h"

int main()
{
	int i,len,id,Windex;
	char buff[20];
	memset(buff,0,10);
	len = 0;
	id = 0;
	Windex = 15;
	//Doc file
	/*	id = Open("Windex.txt",ROFILE);
		len = Read(buff,10,id);
		buff[len] = '\0';
		Close(id);*/

	//Write("\nSo khi ben TAY la : ",20,ConsoleOutput);	
	//Write(buff,10,ConsoleOutput);
	//Windex = __atoi(buff);//chuoi thanh so
	//__itoa(Windex,buff);
	//Write(buff,10,ConsoleOutput);

	for(i = 1; i <= Windex; ++i)
		Monkey(i,WEST);
	Exit(0);
	return 0;
}
