#include "syscall.h"

int main()
{
	char filename[30];
	char buff[100];
	OpenFileId id;
	int kq;

	Write("\nChuong trinh \"cat\" \n",20,ConsoleOutput);
	Write("\nBan hay nhap ten file :",30,ConsoleOutput);
	kq = Read(filename,MaxFileLength,ConsoleInput);
	if(kq < 0)
	{
		Write("\nLoi : Chuoi ban vua nhap khong hop le ",50,ConsoleOutput);		
		Exit(0);
	}
	id = Open(filename,ROFILE);
	if(id < 0)
	{
		Write("\nTen file nay ko co ",50,ConsoleOutput);
		Exit(0);
	}
	
	Write("\nNoi dung cua file ",50,ConsoleOutput);
	Write(filename,30,ConsoleOutput);
	Write(" la :",10,ConsoleOutput);
	kq = -1;
	do
	{
		kq  = Read(buff,100,id);//doc tu file
		Write(buff,100,ConsoleOutput);//xuat ra man hinh
	}while(kq > 0);
	Close(id);
	Exit(0);

} 
