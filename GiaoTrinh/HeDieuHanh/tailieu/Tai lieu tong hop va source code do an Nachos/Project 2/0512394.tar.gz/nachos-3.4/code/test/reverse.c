 
#include "syscall.h"

int main()
{
	char sourcefile[MaxFileLength];
	char destfile[MaxFileLength];
	char buff;
	OpenFileId id_sour,id_dest;
	int kq1;
	int kq2;
	int i;
	int pos;

	//for(i = 0 ; i <= 100 ; i++)
	//	buff[i] = 0;
	Write("\nChuong trinh \"reverse\" \n",30,ConsoleOutput);

	Write("\nBan hay nhap ten file nguon:",30,ConsoleOutput);
	kq1 = Read(sourcefile,MaxFileLength,ConsoleInput);

	Write("\nBan hay nhap ten file dich:",30,ConsoleOutput);
	kq2 = Read(destfile,MaxFileLength,ConsoleInput);

	if(kq1 < 0 || kq2 < 0)
	{
		Write("\nLoi : Chuoi ban vua nhap khong hop le ",50,ConsoleOutput);		
		Exit(1);
	}

	//mo file
	id_sour = Open(sourcefile,ROFILE);
	id_dest = Open(destfile,WRFILE);
	if((id_sour < 2 || id_sour > 9) && (id_dest < 2 || id_dest > 9))
	{
		Write("\nKhong mo file duoc\n",30,ConsoleOutput);
		Exit(1);
	}
	
	//thuc hien viec copy file
	pos = Seek(-1,id_sour);//dua con tro ve vi tri cuoi file
	kq1 = 0;
	i = 1;
	do
	{

		pos = pos -1;
		Seek(pos,id_sour);
		kq1  = Read(buff,1,id_sour);//doc tu file nguon 1 ky tu tu vi tri pos
		
		Write(buff,1,id_dest);//ghi vao file nguon
	
	}while(pos > 0 || kq1 > 0);
	Write("\nCopy xong\n",20,ConsoleOutput);
	Close(id_sour);
	Close(id_dest);
	Exit(0);

} 
 
