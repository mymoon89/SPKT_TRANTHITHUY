#include "syscall.h"
#include "util.h"

void main()
{
	int id;
	CreateSemaphore("Wmultex", 1);
	CreateSemaphore("Emultex", 1);
	CreateSemaphore("Rope", 1);	
	id = Exec("./test/westcross");
//	Join(id);
	id = Exec("./test/eastcross");
//	Join(id);

	Exit(0);
}
