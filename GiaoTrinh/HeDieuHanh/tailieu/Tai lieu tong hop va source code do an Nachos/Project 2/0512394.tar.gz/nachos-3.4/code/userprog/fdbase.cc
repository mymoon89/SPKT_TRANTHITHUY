#include "fdbase.h"

FDBase::~FDBase(){;}

/*
  virtual int   fWrite(int virtAddr,int size) = 0;
  virtual char* fRead(int virtAddr,int size)  = 0;
  virtual int   fClose() = 0;
  //virtual int   fSeek(int pos)  = 0;
*/
