#include "syscall.h"

int main()
{
	char buff[MaxFileLength];
	Write("\n**Chuong trinh creatfile **\n",50,ConsoleOutput);
	Write("\nBan hay ten file :",30,ConsoleOutput);
	Read(buff,MaxFileLength,ConsoleInput);
	CreateFile(buff);
	Exit(0);
//	return 0;
}
