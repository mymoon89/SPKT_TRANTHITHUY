#ifndef global_h
#define global_h

#include "syscall.h"
#include "copyright.h"
#include "util.h"

#define EAST 1
#define WEST 2
void Cross(int index,int Begin)
{
	char buff[10];
	if(Begin == EAST)
	{
		Write("\nCon khi thu : ",30,ConsoleOutput);
		__itoa(index,buff);//so thanh chuoi
		Write(buff,10,ConsoleOutput);
		
		Write(" DONG --> TAY : ",30,ConsoleOutput);
	}
	else
	{
		Write("\nCon khi thu : ",30,ConsoleOutput);
		__itoa(index,buff);//so thanh chuoi
		Write(buff,10,ConsoleOutput);
		Write(" TAY --> DONG : ",30,ConsoleOutput);
	}
}

void WaitUntilSafe(int Begin)
{
	char buff[10];
	int Equeue,Wqueue;//,MaxOnRope;
	int id,len;
	len = 0;
	id = 0;
//	MaxOnRope = 4;
	Equeue = 0;
	Wqueue = 0;

	if(Begin == EAST)
	{
		//while(Equeue < MaxOnRope){
		wait("Emultex");
		//Doc File
		id = Open("Equeue.txt",ROFILE);
		len = Read(buff,5,id);
		Close(id);

		buff[len] = '\0';
		Equeue = __atoi(buff);//chuoi thanh so
		Equeue++;
		//Ghi FILE
		id = Open("Equeue.txt",WRFILE);
		__itoa(Equeue,buff);//so thanh chuoi
		Write(buff,5,id);
		Close(id);

		signal("Emultex");
		
		wait("Rope");
	
	}
	else
	{
		//while(Wqueue < MaxOnRope){
		wait("Wmultex");
		//Doc File
		id = Open("Wqueue.txt",ROFILE);
		len = Read(buff,5,id);
		Close(id);

		buff[len] = '\0';
		Wqueue = __atoi(buff);//chuoi thanh so
		Wqueue++;
		
		//Ghi FILE
		id = Open("Wqueue.txt",WRFILE);
		__itoa(Wqueue,buff);//so thanh chuoi
		Write(buff,5,id);
		Close(id);

		signal("Wmultex");

		wait("Rope");
	}
}

void AfterCross(int Begin)
{
	char buff[10];
	int Equeue;
	int Wqueue;
	int id;
	int len;
	len = 0;
	id = 0;

	if(Begin == EAST)
	{
		wait("Emultex");
		//Doc file
		id = Open("Equeue.txt",ROFILE);
		len = Read(buff,5,id);
		Close(id);

		buff[len] = '\0';
		Equeue = __atoi(buff);//chuoi thanh so
		Equeue--;
		//Ghi FILE
		id = Open("Equeue.txt",WRFILE);
		__itoa(Equeue,buff);//so thanh chuoi
		Write(buff,5,id);
		Close(id);
	
		if(Equeue == 0)
		{
			signal("Emultex");
			signal("Rope");
			return;
		}
		signal("Emultex");
		signal("Rope");
	}
	else
	{
		wait("Wmultex");
		//Doc file
		id = Open("Wqueue.txt",ROFILE);
		len = Read(buff,5,id);
		Close(id);

		buff[len] = '\0';
		Wqueue = __atoi(buff);//chuoi thanh so
		Wqueue--;	
		//Ghi FILE
		id = Open("Wqueue.txt",WRFILE);
		__itoa(Wqueue,buff);//so thanh chuoi
		Write(buff,5,id);
		Close(id);

		if(Wqueue == 0)
		{
			signal("Wmultex");
			signal("Rope");
			return;
		}
		signal("Wmultex");
		signal("Rope");
	}	
}

void Monkey(int index,int Begin)
{
	WaitUntilSafe(Begin);
	Cross(index,Begin);
	AfterCross(Begin);
}

#endif
