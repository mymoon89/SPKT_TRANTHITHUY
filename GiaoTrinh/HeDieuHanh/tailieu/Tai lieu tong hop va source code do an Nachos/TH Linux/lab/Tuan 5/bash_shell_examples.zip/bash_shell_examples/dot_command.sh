#!/bin/sh
echo �Inside script�
PATH=/mypath/bin: /usr/local
echo $PATH
echo �Script end�
