#!/bin/sh

for image in *.gif
do
   cjpeg $image  >${image%%gif}jpg
done
