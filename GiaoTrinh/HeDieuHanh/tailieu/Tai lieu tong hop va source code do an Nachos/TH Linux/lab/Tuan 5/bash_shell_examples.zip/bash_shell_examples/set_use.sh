#!bin/sh
echo Current date is  $(date)
set $(date)
echo The month is $2
echo The year is $6

exit 0
