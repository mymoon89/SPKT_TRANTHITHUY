#! /bin/sh
echo "Try to execute mc program"
exec mc
echo "you can not see this message !"
