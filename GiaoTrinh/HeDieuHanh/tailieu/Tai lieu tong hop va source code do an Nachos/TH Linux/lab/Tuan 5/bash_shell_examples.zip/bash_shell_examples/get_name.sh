#!/bin/sh

yes_or_no() {
  echo "In function parameters are $*"
  echo "Param 1  $1 and Param2  $2"
  while true
  do
    echo -n "Enter yes or no"
    read x
    case "$x" in
      y | yes ) return 0;;
      n | no )  return 1;;
      * )       echo "Answer yes or no"
    esac
  done
}

echo "Original parameters are $*"

if yes_or_no "Is your name� � $1?" 
then
  echo "Hi $1"
elif
  echo "Never mind"
fi

exit 0
