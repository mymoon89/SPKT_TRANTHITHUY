#!/bin/sh
if  [ -f .profile ] ; then
    exit 0
fi
exit 1
