#!/bin/sh
echo Current directory is $PWD
echo It contents $(ls �a) files
exit 0
