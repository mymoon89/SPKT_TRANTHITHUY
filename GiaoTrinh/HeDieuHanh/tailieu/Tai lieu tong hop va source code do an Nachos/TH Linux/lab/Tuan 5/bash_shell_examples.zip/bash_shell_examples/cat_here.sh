#! /bin/sh

cat > test.txt <<!YOURLABEL!
Hello
This is
here document
!YOURLABEL!
