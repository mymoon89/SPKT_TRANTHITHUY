/*
 * RoundComposite.cs
 * 
 * Copyright � 2007 Aptech Software Limited. All rights reserved.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace RoundComposite
{
    /// <summary>
    /// Class RoundComposite is used to demonstrate the use of composite control.
    /// </summary>
    public partial class RoundComposite : UserControl
    {
        /// <summary>
        /// Constructor without parameters to initialize the
        /// controls for displaying the RoundComposite composite control.
        /// </summary>
        public RoundComposite()
        {
            InitializeComponent();
        }

        // Validates the login details.
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtUser.Text == "")
            {
                btnOK.BorderColor = Color.Red;
                MessageBox.Show("Please enter the user id.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnOK.BorderColor = Color.Blue;
                txtUser.Focus();
                return;
            }
            if (txtPassword.Text == "")
            {
                btnOK.BorderColor = Color.Red;
                MessageBox.Show("Please enter the password.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnOK.BorderColor = Color.Blue;
                txtPassword.Focus();
                return;
            }

            if (txtUser.Text != "admin" || txtPassword.Text != "administrator")
            {
                btnOK.BorderColor = Color.Red;
                MessageBox.Show("Either User ID or password is incorrect.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnOK.BorderColor = Color.Blue;
                txtUser.Focus();
                return;
            }
            else
            {
                btnOK.BorderColor = Color.Green;
                MessageBox.Show("You have been logged in successfully.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.ParentForm.Hide();
                this.ParentForm.Validate();
            }
        }

        // Closes the application.
        private void btnCancel_Click(object sender, EventArgs e)
        {
            btnCancel.BorderColor = Color.Red;
            if (MessageBox.Show("Do you want to close the application?", "Login", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                this.ParentForm.Close();
            }
            else
            {
                btnCancel.BorderColor = Color.Blue;
            }
        }
    }
}