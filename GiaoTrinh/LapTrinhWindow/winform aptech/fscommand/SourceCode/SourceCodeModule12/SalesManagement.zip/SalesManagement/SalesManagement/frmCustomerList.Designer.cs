/*
 * frmCustomerList.Designer.cs
 * 
 * Copyright � 2007 Aptech Software Limited. All rights reserved.
 */

namespace SalesManagement
{
    partial class frmCustomerList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "John Smith",
            "J.K.Corner",
            "New Jersey"}, -1);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "Kevin Anderson",
            "George Road",
            "London"}, -1);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "Mark Dolwin",
            "Park Lands End",
            "Madrid"}, -1);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "Chris Brown",
            "Beside Mississippi River",
            "Cincinnati"}, -1);
            this.lvwCustomerList = new System.Windows.Forms.ListView();
            this.chCustomerName = new System.Windows.Forms.ColumnHeader();
            this.chAddress = new System.Windows.Forms.ColumnHeader();
            this.chCity = new System.Windows.Forms.ColumnHeader();
            this.lblList = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvwCustomerList
            // 
            this.lvwCustomerList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chCustomerName,
            this.chAddress,
            this.chCity});
            this.lvwCustomerList.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4});
            this.lvwCustomerList.Location = new System.Drawing.Point(42, 64);
            this.lvwCustomerList.Name = "lvwCustomerList";
            this.lvwCustomerList.Size = new System.Drawing.Size(343, 160);
            this.lvwCustomerList.TabIndex = 1;
            this.lvwCustomerList.UseCompatibleStateImageBehavior = false;
            this.lvwCustomerList.View = System.Windows.Forms.View.Details;
            // 
            // chCustomerName
            // 
            this.chCustomerName.Text = "Customer Name";
            this.chCustomerName.Width = 99;
            // 
            // chAddress
            // 
            this.chAddress.Text = "Address";
            this.chAddress.Width = 133;
            // 
            // chCity
            // 
            this.chCity.Text = "City";
            this.chCity.Width = 107;
            // 
            // lblList
            // 
            this.lblList.AutoSize = true;
            this.lblList.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblList.Location = new System.Drawing.Point(37, 27);
            this.lblList.Name = "lblList";
            this.lblList.Size = new System.Drawing.Size(203, 25);
            this.lblList.TabIndex = 0;
            this.lblList.Text = "List of Customers:";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(310, 245);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmCustomerList
            // 
            this.AcceptButton = this.btnExit;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 280);
            this.ControlBox = false;
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblList);
            this.Controls.Add(this.lvwCustomerList);
            this.Name = "frmCustomerList";
            this.Text = "Customer List Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvwCustomerList;
        private System.Windows.Forms.ColumnHeader chCustomerName;
        private System.Windows.Forms.ColumnHeader chAddress;
        private System.Windows.Forms.ColumnHeader chCity;
        private System.Windows.Forms.Label lblList;
        private System.Windows.Forms.Button btnExit;
    }
}