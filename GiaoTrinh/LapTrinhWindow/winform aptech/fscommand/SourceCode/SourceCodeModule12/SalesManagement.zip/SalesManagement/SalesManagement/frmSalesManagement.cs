/*
 * frmSalesManagement.cs
 * 
 * Copyright � 2007 Aptech Software Limited. All rights reserved.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SalesManagement
{
    /// <summary>
    /// Class frmSalesManagement is used to demonstrate the use of MDI application.
    /// </summary>
    public partial class frmSalesManagement : Form
    {
        /// <summary>
        /// Constructor without parameters to initialize the
        /// controls for displaying the frmSalesManagement form. 
        /// </summary>
        public frmSalesManagement()
        {
            InitializeComponent();
        }

        // Creates Customer Details form
        private void CreateCustomerDetailsForm()
        {
            frmCustomerDetails newMdiChild = new frmCustomerDetails();
            newMdiChild.WindowState = FormWindowState.Maximized;
            newMdiChild.MdiParent = this;
            newMdiChild.Show();
        }

        // Creates Employee Details form
        private void CreateEmployeeDetailsForm()
        {
            frmEmployeeDetails newMdiChild = new frmEmployeeDetails();
            newMdiChild.WindowState = FormWindowState.Maximized;
            newMdiChild.MdiParent = this;
            newMdiChild.Show();
        }

        //Creates Customer List form
        private void CreateCustomerListForm()
        {
            frmCustomerList newMdiChild = new frmCustomerList();
            newMdiChild.WindowState = FormWindowState.Maximized;
            newMdiChild.MdiParent = this;
            newMdiChild.Show();
        }
        
        // Opens the MDI child form
        private void tlstrpmnuitemCustomerDetails_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Length > 0)
            {
                Form[] activeform = this.MdiChildren;
                bool flag = false;
                for (int i = 0; i < activeform.Length; i++)
                {
                    if (activeform[i].Text == "Customer Details")
                    {
                        MessageBox.Show("The window is already running.", "Sales Management", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    CreateCustomerDetailsForm();
                }
            }
            else
            {
                CreateCustomerDetailsForm();
            }
        }
        
        // Opens the MDI child form
        private void tlstrpmnuitemEmployeeDetails_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Length > 0)
            {
                Form[] activeform = this.MdiChildren;
                bool flag = false;
                for (int i = 0; i < activeform.Length; i++)
                {
                    if (activeform[i].Text == "Employee Details")
                    {
                        MessageBox.Show("The window is already running.", "Sales Management", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    CreateEmployeeDetailsForm();
                }
            }
            else
            {
                CreateEmployeeDetailsForm();
            }
        }

        // Opens the MDI child form
        private void tlstrpmnuitemCustomerList_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Length > 0)
            {
                Form[] activeform = this.MdiChildren;
                bool flag = false;
                for (int i = 0; i < activeform.Length; i++)
                {
                    if (activeform[i].Text == "Customer List Report")
                    {
                        MessageBox.Show("The window is already running.", "Sales Management", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        flag = true;
                        break;
                    }
                }
                if(!flag)
                {
                    CreateCustomerListForm();
                }
            }
            else
            {
                CreateCustomerListForm();
            }
        }

        // Closes the application
        private void tlstrpmnuitemExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Opens the MDI child form
        private void tlstrpmnuitemCustomerDetailsContext_Click(object sender, EventArgs e)
        {
            tlstrpmnuitemCustomerDetails_Click(sender, e);
        }

        // Opens the MDI child form
        private void tlstrpmnuitemEmployeeDetailsContext_Click(object sender, EventArgs e)
        {
            tlstrpmnuitemEmployeeDetails_Click(sender, e);
        }

        // Opens the MDI child form
        private void tlstrpmnuitemCustomerListContext_Click(object sender, EventArgs e)
        {
            tlstrpmnuitemCustomerList_Click(sender, e);
        }

        // Opens the dialog box
        private void tlstrpmnuitemAboutUs_Click(object sender, EventArgs e)
        {
            frmAboutUs aboutUs = new frmAboutUs();
            aboutUs.ShowDialog();
        }
    }
}