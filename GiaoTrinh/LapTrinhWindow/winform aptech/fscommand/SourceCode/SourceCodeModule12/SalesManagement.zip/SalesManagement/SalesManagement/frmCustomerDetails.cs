/*
 * frmCustomerDetails.cs
 * 
 * Copyright � 2007 Aptech Software Limited. All rights reserved.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SalesManagement
{
    /// <summary>
    /// Class frmCustomerDetails to open the child form.
    /// </summary>
    public partial class frmCustomerDetails : Form
    {
        /// <summary>
        /// Constructor without parameters to initialize the
        /// controls for displaying the frmCustomerDetails form. 
        /// </summary>
        public frmCustomerDetails()
        {
            InitializeComponent();
        }

        // Closes the form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        // Saves the details
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtCustomerName.Text == "")
            {
                MessageBox.Show("Enter the customer name.", "Sales Management System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                txtCustomerName.Focus();
            }
            else if (txtAddress.Text == "")
            {
                MessageBox.Show("Enter the address.", "Sales Management System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                txtAddress.Focus();
            }
            else if (txtCity.Text == "")
            {
                MessageBox.Show("Enter the city.", "Sales Management System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                txtCity.Focus();
            }
            else
            {
                MessageBox.Show("Customer information submitted successfully.", "Sales Management System", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
    }
}