/*
 * frmLogin.cs
 * 
 * Copyright � 2007 Aptech Software Limited. All rights reserved.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SalesManagement
{
    /// <summary>
    /// Class frmLogin is used to demonstrate the use of composite control.
    /// </summary>
    public partial class frmLogin : Form
    {
        /// <summary>
        /// Constructor without parameters to initialize the
        /// controls for displaying the RoundComposite composite control.
        /// </summary>
        public frmLogin()
        {
            InitializeComponent();
        }

        // Displays the frmSalesManagement MDI form.
        private void rcLogin_Validated(object sender, EventArgs e)
        {
            frmSalesManagement frmSales = new frmSalesManagement();
            frmSales.Show();
        }
    }
}