/*
 * frmAboutUs.cs
 * 
 * Copyright � 2007 Aptech Software Limited. All rights reserved.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SalesManagement
{
    /// <summary>
    /// Class frmAboutUs to open the child form.
    /// </summary>
    public partial class frmAboutUs : Form
    {
        /// <summary>
        /// Constructor without parameters to initialize the
        /// controls for displaying the frmAboutUs form. 
        /// </summary>
        public frmAboutUs()
        {
            InitializeComponent();
        }

        // Closes the form
        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}