/*
 * frmSalesManagement.Designer.cs
 * 
 * Copyright � 2007 Aptech Software Limited. All rights reserved.
 */

namespace SalesManagement
{
    partial class frmSalesManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mnustrpSales = new System.Windows.Forms.MenuStrip();
            this.tlstrpmnuitemForms = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemCustomerDetails = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemEmployeeDetails = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemCustomerList = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemAboutUs = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemExit = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnustrpSales = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tlstrpmnuitemFormsContext = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemCustomerDetailsContext = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemEmployeeDetailsContext = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemReportContext = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstrpmnuitemCustomerListContext = new System.Windows.Forms.ToolStripMenuItem();
            this.mnustrpSales.SuspendLayout();
            this.cmnustrpSales.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnustrpSales
            // 
            this.mnustrpSales.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlstrpmnuitemForms,
            this.tlstrpmnuitemReport,
            this.tlstrpmnuitemHelp,
            this.tlstrpmnuitemExit});
            this.mnustrpSales.Location = new System.Drawing.Point(0, 0);
            this.mnustrpSales.Name = "mnustrpSales";
            this.mnustrpSales.Size = new System.Drawing.Size(485, 24);
            this.mnustrpSales.TabIndex = 1;
            this.mnustrpSales.Text = "standardMenu";
            // 
            // tlstrpmnuitemForms
            // 
            this.tlstrpmnuitemForms.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlstrpmnuitemCustomerDetails,
            this.tlstrpmnuitemEmployeeDetails});
            this.tlstrpmnuitemForms.Name = "tlstrpmnuitemForms";
            this.tlstrpmnuitemForms.Size = new System.Drawing.Size(48, 20);
            this.tlstrpmnuitemForms.Text = "&Forms";
            // 
            // tlstrpmnuitemCustomerDetails
            // 
            this.tlstrpmnuitemCustomerDetails.Name = "tlstrpmnuitemCustomerDetails";
            this.tlstrpmnuitemCustomerDetails.Size = new System.Drawing.Size(166, 22);
            this.tlstrpmnuitemCustomerDetails.Text = "&Customer Details";
            this.tlstrpmnuitemCustomerDetails.ToolTipText = "Enter customer details";
            this.tlstrpmnuitemCustomerDetails.Click += new System.EventHandler(this.tlstrpmnuitemCustomerDetails_Click);
            // 
            // tlstrpmnuitemEmployeeDetails
            // 
            this.tlstrpmnuitemEmployeeDetails.Name = "tlstrpmnuitemEmployeeDetails";
            this.tlstrpmnuitemEmployeeDetails.Size = new System.Drawing.Size(166, 22);
            this.tlstrpmnuitemEmployeeDetails.Text = "&Employee Details";
            this.tlstrpmnuitemEmployeeDetails.ToolTipText = "Enter employee details";
            this.tlstrpmnuitemEmployeeDetails.Click += new System.EventHandler(this.tlstrpmnuitemEmployeeDetails_Click);
            // 
            // tlstrpmnuitemReport
            // 
            this.tlstrpmnuitemReport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlstrpmnuitemCustomerList});
            this.tlstrpmnuitemReport.Name = "tlstrpmnuitemReport";
            this.tlstrpmnuitemReport.Size = new System.Drawing.Size(52, 20);
            this.tlstrpmnuitemReport.Text = "&Report";
            // 
            // tlstrpmnuitemCustomerList
            // 
            this.tlstrpmnuitemCustomerList.Name = "tlstrpmnuitemCustomerList";
            this.tlstrpmnuitemCustomerList.Size = new System.Drawing.Size(150, 22);
            this.tlstrpmnuitemCustomerList.Text = "&Customer List";
            this.tlstrpmnuitemCustomerList.ToolTipText = "Display list of customers";
            this.tlstrpmnuitemCustomerList.Click += new System.EventHandler(this.tlstrpmnuitemCustomerList_Click);
            // 
            // tlstrpmnuitemHelp
            // 
            this.tlstrpmnuitemHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlstrpmnuitemAboutUs});
            this.tlstrpmnuitemHelp.Name = "tlstrpmnuitemHelp";
            this.tlstrpmnuitemHelp.Size = new System.Drawing.Size(40, 20);
            this.tlstrpmnuitemHelp.Text = "&Help";
            // 
            // tlstrpmnuitemAboutUs
            // 
            this.tlstrpmnuitemAboutUs.Name = "tlstrpmnuitemAboutUs";
            this.tlstrpmnuitemAboutUs.Size = new System.Drawing.Size(129, 22);
            this.tlstrpmnuitemAboutUs.Text = "&About Us";
            this.tlstrpmnuitemAboutUs.ToolTipText = "About Sales Management System";
            this.tlstrpmnuitemAboutUs.Click += new System.EventHandler(this.tlstrpmnuitemAboutUs_Click);
            // 
            // tlstrpmnuitemExit
            // 
            this.tlstrpmnuitemExit.Name = "tlstrpmnuitemExit";
            this.tlstrpmnuitemExit.Size = new System.Drawing.Size(37, 20);
            this.tlstrpmnuitemExit.Text = "E&xit";
            this.tlstrpmnuitemExit.ToolTipText = "Exit Sales Management System";
            this.tlstrpmnuitemExit.Click += new System.EventHandler(this.tlstrpmnuitemExit_Click);
            // 
            // cmnustrpSales
            // 
            this.cmnustrpSales.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlstrpmnuitemFormsContext,
            this.tlstrpmnuitemReportContext});
            this.cmnustrpSales.Name = "salesContextMainMenu";
            this.cmnustrpSales.Size = new System.Drawing.Size(119, 48);
            // 
            // tlstrpmnuitemFormsContext
            // 
            this.tlstrpmnuitemFormsContext.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlstrpmnuitemCustomerDetailsContext,
            this.tlstrpmnuitemEmployeeDetailsContext});
            this.tlstrpmnuitemFormsContext.Name = "tlstrpmnuitemFormsContext";
            this.tlstrpmnuitemFormsContext.Size = new System.Drawing.Size(118, 22);
            this.tlstrpmnuitemFormsContext.Text = "&Forms";
            // 
            // tlstrpmnuitemCustomerDetailsContext
            // 
            this.tlstrpmnuitemCustomerDetailsContext.Name = "tlstrpmnuitemCustomerDetailsContext";
            this.tlstrpmnuitemCustomerDetailsContext.Size = new System.Drawing.Size(166, 22);
            this.tlstrpmnuitemCustomerDetailsContext.Text = "Customer Details";
            this.tlstrpmnuitemCustomerDetailsContext.Click += new System.EventHandler(this.tlstrpmnuitemCustomerDetailsContext_Click);
            // 
            // tlstrpmnuitemEmployeeDetailsContext
            // 
            this.tlstrpmnuitemEmployeeDetailsContext.Name = "tlstrpmnuitemEmployeeDetailsContext";
            this.tlstrpmnuitemEmployeeDetailsContext.Size = new System.Drawing.Size(166, 22);
            this.tlstrpmnuitemEmployeeDetailsContext.Text = "Employee Details";
            this.tlstrpmnuitemEmployeeDetailsContext.Click += new System.EventHandler(this.tlstrpmnuitemEmployeeDetailsContext_Click);
            // 
            // tlstrpmnuitemReportContext
            // 
            this.tlstrpmnuitemReportContext.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlstrpmnuitemCustomerListContext});
            this.tlstrpmnuitemReportContext.Name = "tlstrpmnuitemReportContext";
            this.tlstrpmnuitemReportContext.Size = new System.Drawing.Size(118, 22);
            this.tlstrpmnuitemReportContext.Text = "&Report";
            // 
            // tlstrpmnuitemCustomerListContext
            // 
            this.tlstrpmnuitemCustomerListContext.Name = "tlstrpmnuitemCustomerListContext";
            this.tlstrpmnuitemCustomerListContext.Size = new System.Drawing.Size(152, 22);
            this.tlstrpmnuitemCustomerListContext.Text = "Customer List";
            this.tlstrpmnuitemCustomerListContext.Click += new System.EventHandler(this.tlstrpmnuitemCustomerListContext_Click);
            // 
            // frmSalesManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 339);
            this.ContextMenuStrip = this.cmnustrpSales;
            this.Controls.Add(this.mnustrpSales);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mnustrpSales;
            this.Name = "frmSalesManagement";
            this.Text = "Sales Management System";
            this.mnustrpSales.ResumeLayout(false);
            this.mnustrpSales.PerformLayout();
            this.cmnustrpSales.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnustrpSales;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemForms;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemCustomerDetails;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemEmployeeDetails;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemReport;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemCustomerList;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemHelp;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemAboutUs;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemExit;
        private System.Windows.Forms.ContextMenuStrip cmnustrpSales;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemFormsContext;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemCustomerDetailsContext;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemEmployeeDetailsContext;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemReportContext;
        private System.Windows.Forms.ToolStripMenuItem tlstrpmnuitemCustomerListContext;
    }
}

