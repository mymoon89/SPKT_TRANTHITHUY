/*
 * frmCustomerList.cs
 * 
 * Copyright � 2007 Aptech Software Limited. All rights reserved.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SalesManagement
{
    /// <summary>
    /// Class frmCustomerList to open the child form.
    /// </summary>
    public partial class frmCustomerList : Form
    {
        /// <summary>
        /// Constructor without parameters to initialize the
        /// controls for displaying the frmCustomerList form. 
        /// </summary>
        public frmCustomerList()
        {
            InitializeComponent();
        }

        // Closes the form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}