/*
 * frmEmployeeDetails.cs
 * 
 * Copyright � 2007 Aptech Software Limited. All rights reserved.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SalesManagement
{
    /// <summary>
    /// Class frmEmployeeDetails to open the child form.
    /// </summary>
    public partial class frmEmployeeDetails : Form
    {
        /// <summary>
        /// Constructor without parameters to initialize the
        /// controls for displaying the frmEmployeeDetails form. 
        /// </summary>
        public frmEmployeeDetails()
        {
            InitializeComponent();
        }

        // Closes the form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        // Saves the details.
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtEmployeeNo.Text == "")
            {
                MessageBox.Show("Enter the employee number.", "Sales Management System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                txtEmployeeNo.Focus();
            }
            else if (txtFullName.Text == "")
            {
                MessageBox.Show("Enter the full name.", "Sales Management System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                txtFullName.Focus();
            }
            else if (txtCity.Text == "")
            {
                MessageBox.Show("Enter the city.", "Sales Management System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                txtCity.Focus();
            }
            else
            {
                MessageBox.Show("Information submitted successfully.", "Sales Management System", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}