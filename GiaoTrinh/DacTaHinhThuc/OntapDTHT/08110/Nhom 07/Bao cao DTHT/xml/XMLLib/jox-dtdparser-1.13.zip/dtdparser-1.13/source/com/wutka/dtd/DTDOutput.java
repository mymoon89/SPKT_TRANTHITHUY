package com.wutka.dtd;

import java.io.*;

/** Defines the method used for writing DTD information to a PrintWriter
 *
 * @author Mark Wutka
 * @version $Revision: 1.12 $ $Date: 2000/09/01 13:21:05 $ by $Author: wutka $
 */
public interface DTDOutput
{
    public void write(PrintWriter out) throws IOException;
}
